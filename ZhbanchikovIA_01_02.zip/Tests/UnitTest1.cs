﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ZhbanchikovIA_01_02;

namespace Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestQuality_in_QualityRoad()
        {
            QualityRoad quality = new QualityRoad(12, 32, 45);
            Assert.AreEqual(17.28, quality.Quality(),0.01);
        }

        [TestMethod]
        public void TestQualityMiddle_in_RoadTime()
        {
            RoadTime quality = new RoadTime(12, 32, 45,6);
            Assert.AreEqual(19.008, quality.TimeQuality(),0.01);
        }

        [TestMethod]
        public void TestQualityLow_in_RoadTime()
        {
            RoadTime quality = new RoadTime(10, 12, 25, 4);
            Assert.AreEqual(4.8, quality.TimeQuality(), 0.01);
        }

        [TestMethod]
        public void TestQualityHigh_in_RoadTime()
        {
            RoadTime quality = new RoadTime(37, 45, 65, 12);
            Assert.AreEqual(347.2725, quality.TimeQuality(), 0.01);
        }
    }
}
