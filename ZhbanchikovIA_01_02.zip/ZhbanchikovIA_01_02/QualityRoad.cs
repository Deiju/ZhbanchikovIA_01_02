﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZhbanchikovIA_01_02
{
    public class QualityRoad
    {
        public double dlina  { get; set; }
        public double shirina { get; set; }
        public double weight { get; set; }
        public double quality { get; set; }

        public QualityRoad(double Dlina,double Shirina,double Weight)//Конструктор класса
        {
            dlina = Dlina;
            shirina = Shirina;
            weight = Weight;
        }

        public virtual double Quality()// Основной метод для рассчета формулы
        {
            return quality = shirina * dlina * weight/ 1000;
        }
        
        public string String()// Метод для вывода полного сообщения 
        {
            return $"Качество : {Quality()}, Длина: {dlina},Ширина: {shirina},Масса: {weight}";
        }
        
    }
}
