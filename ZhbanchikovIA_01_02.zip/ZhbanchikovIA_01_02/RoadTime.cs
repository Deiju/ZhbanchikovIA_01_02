﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZhbanchikovIA_01_02
{
    public class RoadTime:QualityRoad
    {                
        public int numberMouth { get; set; }

        public RoadTime(double Dlina, double Shirina, double Weight,int number):base(Dlina,Shirina,Weight)//Конструктор класса потомка
        {
            numberMouth = number;
        }

        public virtual double TimeQuality()// Основной метод для рассчета формулы класса потомка
        {
            double qualityP;
            double basequality=Quality();
            if (numberMouth >= 5 && numberMouth <= 8)
            {
                qualityP = basequality * 1.1;
            }
            else if (numberMouth == 3 || numberMouth == 4 || numberMouth == 9 || numberMouth == 10)
            {
                qualityP = basequality * 1.6;
            }
            else
            {
                qualityP = basequality * 2.1 + numberMouth * 10;
            }
            return qualityP;
        }

        public string String()// Метод для вывода полного сообщения 
        {
            return $"Качество работ: {TimeQuality()}, Длина: {dlina},Ширина: {shirina},Масса: {weight}, Номер месяца: {numberMouth}";
        }
    }
}
