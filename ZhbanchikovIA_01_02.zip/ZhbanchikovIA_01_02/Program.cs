﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZhbanchikovIA_01_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double dlina=0.0;//Здесь в основном мы создаём переменные
            double weight = 0.0;
            double shirina = 0.0;
            int numberMouth = 0;
            bool right = false;
            bool numberright = false;
            while (right == false)//Здесь пока мы не введём правильные значения в переменные то не продвинемся дальше
            {
                try
                {
                    Console.WriteLine("Введите длину: ");//Ввод значений
                    dlina = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите массу: ");
                    weight = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите ширина: ");
                    shirina = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Введите номер месяца: ");
                    numberMouth = Convert.ToInt32(Console.ReadLine());
                    while(numberright==false)
                    if (numberMouth > 0 || numberMouth <= 12)
                    {
                        right = true;
                        numberright = true;
                    }
                    else
                    {
                        Console.WriteLine("Error! numbermouth Try again.");
                    }
                    
                }
                catch
                {
                    Console.WriteLine("Error! Try again.");
                }
            }  
            QualityRoad quality = new QualityRoad(dlina, shirina, weight);//Направление данных в классы
            Console.WriteLine(quality.String());//Вывод информации из классов
            RoadTime qualityRoad = new RoadTime(dlina, shirina, weight,numberMouth);
            Console.WriteLine(qualityRoad.String());
            Console.ReadKey();
        }        
    }
}
